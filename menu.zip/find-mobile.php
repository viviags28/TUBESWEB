<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Cari Teman</title>
    <link rel="stylesheet" href="css/style-find-mobile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="app-container">
        <header class="header">
            <div class="search-bar">
                <span>Cari Teman</span>
                <hr>
            </div>
            <div class="icons">
                <i class="fas fa-search"></i>
                <i class="fas fa-bell"></i>
            </div>
        </header>

        <section class="section">
            <h2>Temukan</h2>
            <div class="user-list-scroll">
                <div class="user-card">
                    <img src="img/june.png" alt="June">
                    <div class="user-info">
                        <span class="name">June</span>
                        <span class="level">Menengah</span>
                    </div>
                    <div class="user-badges">
                        <i class="fas fa-eye"></i>
                        <i class="fas fa-comment"></i>
                    </div>
                </div>
                <div class="user-card">
                    <img src="img/juan.png" alt="Juan">
                    <div class="user-info">
                        <span class="name">Juan</span>
                        <span class="level">Pemula</span>
                    </div>
                    <div class="user-badges">
                        <i class="fas fa-eye"></i>
                        <i class="fas fa-comment"></i>
                    </div>
                </div>
                <div class="user-card">
                    <img src="img/toto.png" alt="Toto">
                    <div class="user-info">
                        <span class="name">Toto</span>
                        <span class="level">Mahir</span>
                    </div>
                    <div class="user-badges">
                        <i class="fas fa-eye"></i>
                        <i class="fas fa-comment"></i>
                    </div>
                </div>
                </div>
        </section>

        <section class="section peringkat-section">
    <h2>Peringkat Tertinggi</h2>
    <div class="peringkat-top3">
        <div class="top-user-card rank-1">
            <span class="rank-number gold">1</span>
            <img src="img/budi.png" alt="Budi">
            <span class="name">Budi</span>
            <span class="activity">Dewa Mancing</span>
        </div>
        <div class="top-user-card rank-2">
            <span class="rank-number silver">2</span>
            <img src="img/rahmat.png" alt="Rahmat"> 
            <span class="name">Rahmat</span>
            <span class="activity">Dewa Mancing</span>
        </div>
        <div class="top-user-card rank-3">
            <span class="rank-number bronze">3</span>
            <img src="img/ridwan.png" alt="Ridwan">
            <span class="name">Ridwan</span>
            <span class="activity">Mahir</span>
        </div>
    </div>

            <div class="peringkat-list">
                <div class="peringkat-item rank-4">
                    <img src="img/joko.png" alt="Joko">
                    <span class="name">Joko</span>
                </div>
                <div class="peringkat-item rank-5">
                    <img src="img/bahri.png" alt="Bahri">
                    <span class="name">Bahri</span>
                </div>
                <div class="peringkat-item rank-6">
                    <img src="img/suryana.png" alt="Suryana">
                    <span class="name">Suryana</span>
                </div>
            </div>
        </section>
    </div>
</body>
</html>